#include <stdio.h>
/*
Other include statements may be needed !
*/

void main(int argc, char * argv[])   { 


char * directoryName = argv[1];  /* Directory name to be created */

	/*
		Rest of implementation goes here
	*/
}